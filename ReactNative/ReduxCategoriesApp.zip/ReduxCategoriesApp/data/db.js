export const Categories = [
    {id:1, name:'Bilgisayar', color:"red"},
    {id:2, name:'Telefon', color:"blue"},
    {id:3, name:'Yazıcı', color:"orange"},
    {id:4, name:'OEM Parçalar', color:"maroon"}
];

export const Products = [
    {id:1, name:'Lenovo i7', price:45000, imageUrl: "lenovoi7.jpg", categoryId: 1},
    {id:2, name:'Lenovo i5', price:45000, imageUrl: "asus.jpg", categoryId: 1},
    {id:3, name:'IPhone 14', price:45000, imageUrl: "IPhone14.jpg", categoryId: 2},
    {id:4, name:'Samsung S23', price:45000, imageUrl: "IPhone14.jpg", categoryId: 2},
    {id:5, name:'Canon Printer', price:45000, imageUrl: "canon.jpg", categoryId: 3},
    {id:6, name:'HP Yazıcı', price:45000, imageUrl: "canon.jpg", categoryId: 3}
];