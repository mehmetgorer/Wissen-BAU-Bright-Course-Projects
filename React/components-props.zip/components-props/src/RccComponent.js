import React, { Component } from 'react'

export default class RccComponent extends Component {
  render() {
    return (
      <div>React Class Component</div>
    )
  }
}
